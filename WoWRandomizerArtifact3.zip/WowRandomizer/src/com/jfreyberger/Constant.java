package com.jfreyberger;

public final class Constant {
	//url
	public static final String DB_URL = "jdbc:postgresql://db.bit.io:5432/bitdotio";
	//username
	public static final String USER_NAME = "sql3453853";
	//password
	public static final String PASSWORD = "NHDj_G5KskMTFiJ5Gh8ySada5MCe";
}
